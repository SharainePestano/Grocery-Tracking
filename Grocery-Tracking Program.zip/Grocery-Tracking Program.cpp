#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iomanip>

using namespace std;

// Function to read data from input file and return item frequencies
map<string, int> LoadData(const string& filename) {
    map<string, int> frequency;
    ifstream file(filename);
    string item;

    while (file >> item) {
        ++frequency[item];
    }

    file.close();
    return frequency;
}

// Function to write frequencies to backup file
void WriteFrequencyFile(const map<string, int>& frequency, const string& outFile) {
    ofstream out(outFile);
    for (const auto& pair : frequency) {
        out << pair.first << " " << pair.second << endl;
    }
    out.close();
}

// Function to search for a specific item
void SearchItem(const map<string, int>& frequency) {
    string item;
    cout << "Enter item to search: ";
    cin >> item;

    auto it = frequency.find(item);
    if (it != frequency.end()) {
        cout << item << " appears " << it->second << " time(s).\n";
    }
    else {
        cout << item << " not found.\n";
    }
}

// Function to display all items with their frequencies
void PrintAllItems(const map<string, int>& frequency) {
    cout << "\nITEM FREQUENCIES\n----------------\n";
    for (const auto& pair : frequency) {
        cout << setw(12) << left << pair.first << ": " << pair.second << endl;
    }
    cout << endl;
}

// Function to display histogram
void PrintHistogram(const map<string, int>& frequency) {
    cout << "\nPURCHASE HISTOGRAM\n------------------\n";
    for (const auto& pair : frequency) {
        cout << setw(12) << left << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            cout << "*";
        }
        cout << endl;
    }
    cout << endl;
}

int main() {
    const string inputFile = "CS210_Project_Three_Input_File.txt";
    const string frequencyFile = "frequency.dat";

    // Load data and write backup
    map<string, int> frequency = LoadData(inputFile);
    WriteFrequencyFile(frequency, frequencyFile);

    // Menu loop
    int choice = 0;
    do {
        cout << "CORNER GROCER ITEM TRACKER\n";
        cout << "--------------------------\n";
        cout << "1. Search for an item\n";
        cout << "2. Display all item frequencies\n";
        cout << "3. Display histogram of item frequencies\n";
        cout << "4. Exit\n";
        cout << "Enter your choice (1-4): ";
        cin >> choice;

        switch (choice) {
        case 1:
            SearchItem(frequency);
            break;
        case 2:
            PrintAllItems(frequency);
            break;
        case 3:
            PrintHistogram(frequency);
            break;
        case 4:
            cout << "Exiting program. Goodbye!\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }

    } while (choice != 4);

    return 0;
}
